<div class="col-12 col-lg-3 col-xl-2 vh-100 sidebar">
                <div class="d-flex justify-content-between align-items-center py-2 mt-2">
                    <div class="d-flex  align-items-center">
                        <span class="bg-primary rounded p-2 d-flex justify-content-center align-items-center mr-2">
                            <i class="feather-shopping-bag text-light"></i>
                        </span>
                        <span class="font-weight-bolder h4 mb-0">MY SHOP</span>
                    </div>
                    <button class="hide-sidebar-btn btn btn-light d-block d-lg-none">
                        <i class="feather-x text-primary" style="font-size: 2em;"></i>
                    </button>

                </div>
                
                <div class="nav-menu mt-3">
                    <ul>

                        <li class="menu-item">
                            <a href="<?php echo $url; ?>/dashboard.php" class="menu-item-link">
                                <span>
                                    <i class="feather-home"></i>
                                    Dashboard Home
                                </span>
                            </a>
                        </li>

                        <li class="menu-spacer">

                        </li>
                    </ul>
                    <ul>
                        <li class="menu-title">
                            <span>Manage Item</span>
                        </li>
                        <li class="menu-item">
                            <a href="<?php echo $url; ?>/item-list.php" class="menu-item-link">
                                <span>
                                    <i class="feather-list"></i>
                                    Item List
                                </span>
                            </a>
                        </li>
                        <li class="menu-item">
                            <a href="<?php echo $url; ?>/add-item-list.php" class="menu-item-link">
                                <span>
                                    <i class="feather-plus-circle"></i>
                                    Add Item
                                </span>
                                <span class="bg-black shadow-sm badge badge-pill">15</span>
                            </a>
                        </li>
                        <li class="menu-spacer">
                        </li>
                        <li class="menu-item">
                            <a href="<?php echo $url; ?>/category-create.php" class="menu-item-link">
                                <span>
                                <i class="feather-plus-circle"></i>
                                    category add
                                </span>
                            </a>
                        </li>
                        <li class="menu-item">
                            <a href="<?php echo $url; ?>/category-list.php" class="menu-item-link">
                                <span>
                                    
                                    <i class="feather-list"></i>
                                    cateory list
                                </span>
                                <span class="bg-black shadow-sm badge badge-pill">15</span>
                            </a>
                        </li>
                        <li class="menu-spacer">
                        </li>
                        <li class="menu-item">
                            <a href="<?php echo $url; ?>/logout.php" class="w-100 btn btn-outline-primary">
                                <span>
                                    
                                    <i class="feather-lock"></i>
                                    Log out
                                </span>
                                
                            </a>
                        </li>
                        <li class="menu-spacer">
                        </li>

                    </ul>

                    

                    

                </div>
            </div>