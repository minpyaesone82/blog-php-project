<?php include "template/header.php" ?>

<div class="row ">
                        <div class="col-12">
                           <div class="card ">
                                <div class="card-body" style="margin: -10px;">
                                    <div class="d-flex justify-content-between align-items-center">
                                       <h5 class="m-0">
                                          <i class="feather-list text-primary">List item</i>
                                       </h5>
                                       <a href="<?php echo $url; ?>/category-create.php">
                                           <i class="feather-plus-circle btn btn-outline-primary"></i>
                                       </a>
                                    </div>
                                    <hr>
                                    <table id="list" class="table  table-striped table-hover"  style="width:100%">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Category Name</th>
                                                <th>Control</th>
                                                <th>Created_at</th>
                                                
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                                foreach (categoryList() as $rows) {
                                                    $time = date("g:i", strtotime($rows['created_at']));
                                               
                                            
                                            ?>

                                            <tr>
                                                <td><?php echo $rows["id"] ?></td>
                                                <td><?php echo $rows["message"] ?></td>
                                                <td>
                                                <a href='category-delete.php?id=<?php echo $rows["id"]?>' class="btn btn-sm btn-danger">delete</a>
                                                <a href='category-update.php?id=<?php echo $rows["id"]?>' class="btn btn-sm btn-warning">update</a>
                                                </td>
                                                <td><?php echo $time ?></td>   
                                            </tr>

                                            <?php
                                            
                                             }
                                            ?>
                                        </tbody>
                                       
                                        
                                    </table>
                                </div>
                                
                           </div>
                        
                        </div>
                        
                       
                    </div>
                

<?php include "template/footer.php"?>
<script src="<?php echo $url; ?>/assets/vendor/data_table/jquery.dataTables.min.js"></script>
<script src="<?php echo $url; ?>/assets/vendor/data_table/dataTables.bootstrap4.min.js"></script>
<script>
    $('#list').DataTable({
        order:[[0,"desc"]]
    });
</script>