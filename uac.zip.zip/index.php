<?php include "template/header.php" ?>

    <h1>This is index page</h1>

<?php include "template/footer.php"?>