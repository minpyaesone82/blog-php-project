<?php 
    $data = ["name" => "minpyaesone", "age" => 22];

    function con(){
       return mysqli_connect("localhost","root","","blog");
    }

    $row = ["role","editor","user"];

    $url = "http://{$_SERVER["HTTP_HOST"]}/blog-project";