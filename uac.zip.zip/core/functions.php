<?php

    //password wrong alert start
    function wrongalert($data){
        return "<p style='background:#da8f97;padding:6px 0 6px 10px;font-size:10px;font-weight:600;'>$data</p>";
    }
    function correctalert($data){
        return "<p style='background:var(--info);padding:6px 0 6px 10px;font-size:10px;font-weight:600;'>$data</p>";
    }
    //password wrong alert end

    // register start
    function register(){
        $name = $_POST['name'];
        $email = $_POST['email'];
        $password = $_POST['password'];
        $cpassword = $_POST['cpassword'];
        
        if($password == $cpassword){
            $spass = password_hash($password,PASSWORD_DEFAULT);
            $sql =  "INSERT INTO users(name,email,password) VALUES ('$name','$email','$spass')";
            mysqli_query(con(),$sql);
            
        }else{
           return wrongalert('Password do not match');
        }
    }

    //register end


    //login start
        function login(){
            $email = $_POST['email'];
            $password = $_POST['password'];
            $sql = "SELECT * FROM  users WHERE email= '$email'";
            $query = mysqli_query(con(),$sql);
            $row= mysqli_fetch_assoc($query);

            if(!$row){
                return wrongalert("Email or Password do not match"); 
            }else{
                if(!password_verify($password,$row['password'])){
                    return wrongalert("Email or Password do not match");
                }else{
                    session_start();
                     $_SESSION['users'] = $row; 
                    header("location:dashboard.php");
                }
            }
        }
    //login end
